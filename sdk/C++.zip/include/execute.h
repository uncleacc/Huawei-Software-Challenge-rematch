#ifndef CODECRAFTSDK_EXECUTE_H
#define CODECRAFTSDK_EXECUTE_H


class execute {
public:
    execute();
    ~execute();

    void execute_buy();
    void execute_robot();
    void execute_boat();

};


#endif //CODECRAFTSDK_EXECUTE_H
